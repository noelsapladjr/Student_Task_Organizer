<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, initial-scale=1">
    <title>Student Task Organizer - User Information</title>
    <link rel="icon" href="../Images/1.png" type="image/png">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <link rel="stylesheet" href="../CSS/users.css">
</head>

<body>
    <input type="checkbox" id="menu-toggle">
    <div class="sidebar">
        <div class="brand">
            <span class="las la-clipboard-check"></span>
            <h2>Student Task Organizer</h2>
        </div>

        <div class="sidemenu">
            <div class="side-user">
                <div id="preview-image" class="profile-image-placeholder" style="background-image: url('<?php echo isset($_SESSION['profile_pic']) ? "../profile_pics/" . $_SESSION['profile_pic'] : "../Images/default1.jpg"; ?>')"></div>
                <div class="user">
                    <small>Student</small>
                    <p><span id="userName"><?php echo $_SESSION['username']; ?></span></p>
                </div>
            </div>

            <ul>
                <li><a href="../HTML/welcome.php"><span class="las la-home"></span><span>Dashboard</span></a></li>
                <li><a href="tasks.php"><span class="las la-check-circle"></span><span>Tasks</span></a></li>
                <li><a href="../HTML/about.php"><span class="las la-envelope"></span><span>About</span></a></li>
                <li><a href="users.php" class="active"><span class="las la-user"></span><span>User Information</span></a></li>
                <li><a href="../HTML/help.php"><span class="las la-hands-helping"></span><span>Help</span></a></li>
                <li><a href="#" onclick="openLogoutPopup()"><span class="las la-lock"></span><span>Log Out</span></a></li>
            </ul>
        </div>
    </div>

    <div class="main-content">
        <header>
            <label for="menu-toggle" class="menu-toggler"><span class="las la-bars"></span></label>
        </header>

        <div class="profile-section">
            <div class="profile-header">
                <div id="preview-image" class="profile-image-placeholder" style="background-image: url('<?php echo isset($_SESSION['profile_pic']) ? "../profile_pics/" . $_SESSION['profile_pic'] : "../Images/default1.jpg"; ?>')"></div>
            </div>
            <div class="profile-info">
                <small class="user-type">Student</small>
                <p id="user-name-placeholder"><?php echo $_SESSION['username']; ?></p>
            </div>
            <hr class="separator">
        </div>

        <div class="user-information-section">
            <h2>User Information</h2>
            <form id="profile-form">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="John Doe" readonly>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="john_doe123" readonly>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="john.doe@example.com" readonly>
                <label for="contact-number">Contact Number</label>
                <input type="tel" id="contact-number" name="contact-number" placeholder="+1 123-456-7890" readonly>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="********">
                <button type="button" class="edit-information-btn" onclick="openEditInfoPopup()">Edit Information</button>
            </form>
        </div>

        <div class="popup-container" id="editInfoPopup">
            <div class="popup-content">
                <h2>Edit User Information</h2>
                <div class="profile-section">
                    <div class="profile-header">
                        <div id="preview-image" class="profile-image-placeholder" style="background-image: url('<?php echo isset($_SESSION['profile_pic']) ? "../profile_pics/" . $_SESSION['profile_pic'] : "../Images/default1.jpg"; ?>')"></div>
                    </div>
                    <div class="profile-info">
                        <small class="user-type">Student</small>
                        <p id="user-name-profile"><?php echo $_SESSION['username']; ?></p>
                    </div>
                    <hr class="separator">
                </div>

                <h2>User Information</h2>
                <form id="editInfoForm" enctype="multipart/form-data">
                    <label for="profile-pic-upload">Upload Profile Picture</label>
                    <input type="file" id="profile-pic-upload" accept="image/*">
                    <label for="editName">Name</label>
                    <input type="text" id="editName" name="editName" placeholder="John Doe">
                    <label for="editUsername">Username</label>
                    <input type="text" id="editUsername" name="editUsername" placeholder="john_doe123">
                    <label for="editEmail">Email</label>
                    <input type="email" id="editEmail" name="editEmail" placeholder="john.doe@example.com">
                    <label for="editContactNumber">Contact Number</label>
                    <input type="tel" id="editContactNumber" name="editContactNumber" placeholder="+1 123-456-7890">
                    <label for="editPassword">Password</label>
                    <input type="password" id="editPassword" name="editPassword" placeholder="********">
                    <button type="button" class="btn save-btn" onclick="saveAndClose()">Save</button>
                    <button type="button" class="btn close-btn" onclick="closeEditInfoPopup()">Close</button>
                </form>
            </div>
        </div>

        <label class="close-mobile-menu" for="menu-toggle"></label>

        <div class="popup-container" id="logoutPopup">
            <div class="popup-content">
                <img src="../Images/lock.png" alt="Logo" class="logo-image">
                <h2>Logout Confirmation</h2>
                <p>Are you sure you want to logout?</p>
                <div class="button-container">
                    <button class="btn" onclick="confirmLogout()">YES</button>
                    <button class="btn closeBtn" onclick="closeLogoutPopup()">NO</button>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                document.getElementById('profile-pic-upload').addEventListener('change', uploadProfilePicture);
            });

            function uploadProfilePicture() {
                var fileInput = document.getElementById('profile-pic-upload');
                var file = fileInput.files[0];
                var formData = new FormData();
                formData.append('profile-pic', file);

                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'upload_profile_pic.php', true);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            var previewImage = document.querySelector('.profile-image-placeholder');
                            previewImage.style.backgroundImage = 'url(' + response.newImagePath + ')';
                            var defaultImages = document.querySelectorAll('[style*="default1.jpg"]');
                            defaultImages.forEach(function (element) {
                                element.style.backgroundImage = 'url(' + response.newImagePath + ')';
                            });
                        } else {
                            alert('Error: ' + response.message);
                        }
                    }
                };
                xhr.send(formData);
            }

            function openEditInfoPopup() {
                document.getElementById('editName').value = "<?php echo $_SESSION['name']; ?>";
                document.getElementById('editUsername').value = "<?php echo $_SESSION['username']; ?>";
                document.getElementById('editEmail').value = "<?php echo $_SESSION['email']; ?>";
                document.getElementById('editContactNumber').value = "<?php echo $_SESSION['contact']; ?>";
                document.getElementById('user-name-profile').innerText = "<?php echo $_SESSION['username']; ?>";
                document.getElementById('editInfoPopup').style.display = 'block';
            }

            function closeEditInfoPopup() {
                document.getElementById('editInfoPopup').style.display = 'none';
            }

            function saveAndClose() {
                var newName = document.getElementById('editName').value;
                var newUsername = document.getElementById('editUsername').value;
                var newEmail = document.getElementById('editEmail').value;
                var newContactNumber = document.getElementById('editContactNumber').value;
                var newPassword = document.getElementById('editPassword').value;
                var profilePicFile = document.getElementById('profile-pic-upload').files[0];

                var formData = new FormData();
                formData.append('name', newName);
                formData.append('username', newUsername);
                formData.append('email', newEmail);
                formData.append('contact', newContactNumber);
                formData.append('password', newPassword);
                formData.append('profile-pic', profilePicFile);

                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'update_user.php', true);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            document.getElementById('name').value = newName;
                            document.getElementById('username').value = newUsername;
                            document.getElementById('email').value = newEmail;
                            document.getElementById('contact-number').value = newContactNumber;

                            var previewImage = document.querySelector('.profile-image-placeholder');
                            previewImage.style.backgroundImage = 'url(' + response.newImagePath + ')';

                            closeEditInfoPopup();
                            alert("Changes have been successfully updated.");
                            setTimeout(function () {
                                window.location.reload();
                            }, 1000);
                        } else {
                            alert("Failed to update user information: " + response.message);
                        }
                    }
                };

                xhr.send(formData);
            }

            function populateUserInfo() {
                var name = "<?php echo $_SESSION['name']; ?>";
                var username = "<?php echo $_SESSION['username']; ?>";
                var email = "<?php echo $_SESSION['email']; ?>";
                var contact = "<?php echo $_SESSION['contact']; ?>";
                var profilePic = "<?php echo isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : 'default1.jpg'; ?>";

                document.getElementById('name').value = name;
                document.getElementById('username').value = username;
                document.getElementById('email').value = email;
                document.getElementById('contact-number').value = contact;

                var previewImage = document.getElementById('preview-image');
                previewImage.style.backgroundImage = 'url("../profile_pics/' + profilePic + '")';

                document.getElementById('user-name-placeholder').innerText = username;
            }

            window.onload = function() {
                populateUserInfo();
            };
        </script>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
        <script src="../JS/users.js"></script>
    </div>
</body>
</html>
