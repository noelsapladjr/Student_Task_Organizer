<?php
$host = 'localhost'; // Database host
$db_username = 'root'; // MySQL username
$db_password = ''; // MySQL password
$dbname = 'student_taskdb'; // Database name

// Create a new connection
$connection = new mysqli($host, $db_username, $db_password, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Get and sanitize user registration data from the POST data
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$contact = trim($_POST['contact']);
$user_username = trim($_POST['username']);
$password = $_POST['password']; // No hashing, using plain text password

// Use prepared statements to securely insert data into the database
$stmt = $connection->prepare("INSERT INTO users (name, email, contact, username, password) VALUES (?, ?, ?, ?, ?)");
if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}

$stmt->bind_param("sssss", $name, $email, $contact, $user_username, $password);

// Execute the statement and check if it was successful
if ($stmt->execute()) {
    echo "success";
} else {
    echo "Error: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$connection->close();
?>
