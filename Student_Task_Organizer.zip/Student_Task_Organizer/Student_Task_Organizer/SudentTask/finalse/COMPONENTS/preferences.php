<?php
session_start();
$userid = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Function to establish a database connection
    function connection(){
        $conn = mysqli_connect('localhost', 'root', '', 'student_taskdb');
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        return $conn;
    }

    // Function to get user preferences from the database
    function getPreferences($userid){
        $conn = connection();
        $query = "SELECT * FROM preferences WHERE user_id = '$userid'";
        $result = mysqli_query($conn, $query);
        $rows = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        mysqli_close($conn); // Close the connection
        return $rows;
    }

    // Default values
    $fs = "14";
    $fst = "normal";
    $ff = "Arial";
    $sort = "deadline";
    $cc = "#ffffff";

    if (isset($_POST['action']) && $_POST['action'] == 'apply') {
        $result = getPreferences($userid);
        
        // If there are existing preferences, use them; otherwise, use defaults
        if (!empty($result)) {
            $fs = !empty($_POST['fontSize']) ? $_POST['fontSize'] : $result[0]['font_size'];
            $fst = !empty($_POST['fontStyle']) ? $_POST['fontStyle'] : $result[0]['font_style'];
            $ff = !empty($_POST['fontFamily']) ? $_POST['fontFamily'] : $result[0]['font_family'];
            $cc = !empty($_POST['colorCoding']) ? $_POST['colorCoding'] : $result[0]['colors'];
            $sort = !empty($_POST['sort']) ? $_POST['sort'] : $result[0]['sort'];
        }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'reset') {
        // Reset button clicked - use default values
        $fs = "14"; 
        $fst = "normal";
        $ff = "Arial";
        $sort = "deadline";
        $cc = "#ffffff";
    }

    // Check if preferences already exist for the user
    $preferencesExist = "SELECT user_id FROM preferences WHERE user_id='$userid'"; 
    $conn = connection();
    $checkExistingQuery = mysqli_query($conn, $preferencesExist);
    
    if (!$checkExistingQuery) {
        echo "Error checking existing preferences: " . mysqli_error($conn);
    } else {
        if (mysqli_num_rows($checkExistingQuery) > 0) {
            // User preferences already exist, update them
            $sql = "UPDATE preferences SET font_size=?, font_style=?, font_family=?, sort=?, colors=? WHERE user_id=?";
        } else {
            // User preferences don't exist, insert new preferences
            $sql = "INSERT INTO preferences (font_size, font_style, font_family, sort, colors, user_id) VALUES (?, ?, ?, ?, ?, ?)";
        }

        // Prepare and execute the SQL statement
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssss", $fs, $fst, $ff, $sort, $cc, $userid);
        
        if (mysqli_stmt_execute($stmt)) {
            if (mysqli_affected_rows($conn) > 0) {
                echo "Success " . (mysqli_num_rows($checkExistingQuery) > 0 ? "updating" : "adding") . " your preferences";
            } else {
                echo "No changes made to preferences";
            }
        } else {
            echo "Error " . (mysqli_num_rows($checkExistingQuery) > 0 ? "updating" : "adding") . " preferences: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);
}

echo "<script>window.history.go(-1);</script>";
echo "<script>window.location.href = 'tasks.php';</script>";
?>
