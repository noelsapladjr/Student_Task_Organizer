<?php
session_start();

// DB Connection
$connection = new mysqli("localhost", "root", "", "student_taskdb");
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$username = trim(mysqli_real_escape_string($connection, $_POST['username']));
$password = trim(mysqli_real_escape_string($connection, $_POST['password']));

// Check if username exists
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($connection, $sql);

if (!$result) {
    echo "SQL error: " . mysqli_error($connection);
    exit;
}

if (mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);

    // Debug output:
    // echo "Input Password: '$password' - Stored: '" . $user['password'] . "'";
    
    if ($password === trim($user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $user['name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['contact'] = $user['contact'];

        header("Location: ../HTML/welcome.php");
        exit();
    } else {
        echo "Password mismatch. Input: '$password' | Stored: '" . $user['password'] . "'";
    }
} else {
    echo "Username not found: '$username'";
}

mysqli_close($connection);
?>
