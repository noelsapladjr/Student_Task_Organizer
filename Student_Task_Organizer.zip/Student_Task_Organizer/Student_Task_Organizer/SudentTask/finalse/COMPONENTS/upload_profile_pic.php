<?php
session_start();

// DB connection
$connection = new mysqli("localhost", "root", "", "student_taskdb");
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Initialize response
$response = ['success' => false, 'message' => ''];

if (!isset($_SESSION['username'])) {
    $response['message'] = "User not logged in.";
    echo json_encode($response);
    exit();
}

if (isset($_FILES['profile-pic'])) {
    $file = $_FILES['profile-pic'];
    $fileError = $file['error'];

    if ($fileError === UPLOAD_ERR_OK) {
        // Validate file type and size
        $allowedExts = ['jpg', 'jpeg', 'png', 'gif'];
        $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($fileExt, $allowedExts)) {
            $response['message'] = "Only JPG, JPEG, PNG, and GIF files are allowed.";
        } elseif ($file['size'] > 2 * 1024 * 1024) {
            $response['message'] = "File size exceeds 2MB limit.";
        } else {
            // Prepare for upload
            $uploadDir = "../profile_pics/";
            $uniqueFilename = uniqid("profile_pic_") . '.' . $fileExt;
            $uploadPath = $uploadDir . $uniqueFilename;

            if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                // Save filename in DB with username
                $username = $_SESSION['username'];
                $stmt = $connection->prepare("INSERT INTO profile_pictures (username, image_url) VALUES (?, ?)");
                $stmt->bind_param("ss", $username, $uniqueFilename);

                if ($stmt->execute()) {
                    $_SESSION['profile_pic'] = $uniqueFilename;
                    $response = [
                        'success' => true,
                        'message' => "Profile picture uploaded successfully.",
                        'newImagePath' => $uniqueFilename
                    ];
                } else {
                    $response['message'] = "Failed to insert profile picture into database.";
                }

                $stmt->close();
            } else {
                $response['message'] = "Failed to move uploaded file.";
            }
        }
    } else {
        $response['message'] = "Upload error code: $fileError";
    }
} else {
    $response['message'] = "No file uploaded.";
}

$connection->close();
echo json_encode($response);
