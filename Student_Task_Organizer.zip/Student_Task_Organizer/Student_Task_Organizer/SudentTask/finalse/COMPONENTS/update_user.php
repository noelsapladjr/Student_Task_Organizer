<?php
session_start();

// DB connection
$connection = new mysqli("localhost", "root", "", "student_taskdb");
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check login
if (!isset($_SESSION['username'])) {
    echo json_encode(["success" => false, "message" => "User not logged in"]);
    exit();
}

// Get current username
$currentUsername = $_SESSION['username'];

// Get and validate POST data
$newName = $_POST['name'] ?? '';
$newEmail = $_POST['email'] ?? '';
$newContact = $_POST['contact'] ?? '';
$newUsername = $_POST['username'] ?? '';
$newPassword = $_POST['password'] ?? '';

if (!$newName || !$newEmail || !$newContact || !$newUsername || !$newPassword) {
    echo json_encode(["success" => false, "message" => "All fields are required."]);
    exit();
}

$newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

// Use prepared statement for security
$stmt = $connection->prepare("UPDATE `register` SET `name` = ?, `email` = ?, `contact_number` = ?, `username` = ?, `password` = ? WHERE `username` = ?");
$stmt->bind_param("ssssss", $newName, $newEmail, $newContact, $newUsername, $newPasswordHash, $currentUsername);

if ($stmt->execute()) {
    // Update session variables
    $_SESSION['name'] = $newName;
    $_SESSION['email'] = $newEmail;
    $_SESSION['contact'] = $newContact;
    $_SESSION['username'] = $newUsername;

    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Update failed: " . $stmt->error]);
}

$stmt->close();
$connection->close();
