<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Set character set and viewport for responsiveness -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, initial-scale=1" />
    <title>Student Task Organizer - About</title>
    <!-- Add Favicon -->
    <link rel="icon" href="../Images/1.png" type="image/png" />
    <!-- Include Line Awesome CSS library -->
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" />
    <!-- Include Morris.js CSS library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" />
    <!-- Include custom CSS file "members.css" -->
    <link rel="stylesheet" href="../CSS/members.css" />
</head>

<body>
    <!-- Checkbox for mobile menu toggle -->
    <input type="checkbox" id="menu-toggle" />
    <!-- Sidebar navigation -->
    <div class="sidebar">
        <div class="brand">
            <!-- Logo and application name -->
            <span class="las la-clipboard-check"></span>
            <h2>Student Task Organizer</h2>
        </div>

        <!-- User information in the sidebar -->
        <div class="sidemenu">
            <div class="side-user">
                <!-- User image -->
                <div id="preview-image" class="profile-image-placeholder" style="background-image: url('<?php echo isset($_SESSION['profile_pic']) ? "../profile_pics/" . $_SESSION['profile_pic'] : "../Images/default1.jpg"; ?>')"></div>
                <div class="user">
                    <!-- User role and name -->
                    <small>Student</small>
                    <p><span id="userName"></span></p>
                </div>
            </div>

            <!-- Navigation links in the sidebar -->
            <ul>
                <li>
                    <a href="welcome.php">
                        <span class="las la-home"></span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../COMPONENTS/tasks.php">
                        <span class="las la-check-circle"></span>
                        <span>Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="about.php" class="active">
                        <span class="las la-envelope"></span>
                        <span>About</span>
                    </a>
                </li>
                <li>
                    <a href="../COMPONENTS/users.php">
                        <span class="las la-user"></span>
                        <span>User Information</span>
                    </a>
                </li>
                <li>
                    <a href="help.php">
                        <span class="las la-hands-helping"></span>
                        <span>Help</span>
                    </a>
                </li>
                <li>
                    <a href="#" onclick="openLogoutPopup()">
                        <span class="las la-lock"></span>
                        <span>Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main content section -->
    <div class="main-content">
        <header>
            <!-- Label for mobile menu toggle -->
            <label for="menu-toggle" class="menu-toggler">
                <span class="las la-bars"></span>
            </label>
        </header>

        <!-- Mission, Vision, and Goals Section -->
        <section class="mission-vision-goals">
            <h1 class="heading">
                Mission, <span class="heading1">Vision, <span class="heading2">Goals</span></span>
            </h1>
        </section>

        <!-- Mission Section -->
        <section class="mission-section">
            <h2>Mission</h2>
            <p>Our mission at Student Task Organizer is to empower students by providing a comprehensive task management system that streamlines their academic workload. We are committed to enhancing productivity, fostering organization, and promoting accountability among students. By offering a centralized platform for managing tasks, deadlines, and progress, we strive to contribute to students' success in their academic journey.</p>
        </section>

        <!-- Vision Section -->
        <section class="vision-section">
            <h2>Vision</h2>
            <p>Our vision is to emerge as the foremost provider of student task management systems, recognized for our user-friendly interface, innovative features, and steadfast commitment. We aspire to contribute significantly to the academic success and personal growth of students. At Student Task Organizer, we envision a future where every student possesses the necessary tools to excel in both studies and responsibilities, fostering a community of learners who are well-organized, motivated, and equipped to confront the challenges of education. Our goal is to make a meaningful impact on the educational landscape by continuously enhancing and adapting our platform to meet the evolving needs of students and the changing educational environments.</p>
        </section>

        <!-- Goals Section -->
        <section class="goals-section">
            <h2>Goals</h2>
            <ul>
                <li>Empower Students: Provide a user-friendly platform that empowers students to take control of their academic responsibilities, promoting self-management and a sense of accomplishment.</li>
                <li>Enhance Productivity: Develop features that streamline tasks, deadlines, and progress tracking, ultimately enhancing students' productivity and reducing academic stress.</li>
                <li>Facilitate Time Management: Enable students to create personalized schedules, set goals, and break down activities into manageable parts, fostering effective time management skills.</li>
                <li>Promote User Adoption: Implement user education and support initiatives to overcome resistance to change, ensuring widespread adoption and utilization of the system.</li>
                <li>Stand Out in a Crowded Market: Develop a potent marketing and sales strategy to differentiate Student Task Organizer in a competitive market, ensuring sustained profitability and growth.</li>
            </ul>
        </section>

        <!-- Separator -->
        <hr class="section-separator" />

        <!-- Team Members Section -->
        <section class="members" id="members">
            <h1 class="heading">System <span class="members-color">Creator</span></h1>
            <div class="members-container">

            <div class="members-box" data-info="Cyril T. Torion" data-description="<p>UI/UX Designer & Technical Writer</p><br><br>
                <p>Hello, everyone! My name is Cyril T. Torion, and I'm currently a second-year student at Bisu Balilihan pursuing a Bachelor of Science in Information Technology (BSIT). I am passionate about the world of computer and information sciences, and I've had the incredible opportunity to be part of a team that developed this website!</p><br><br>
                <p>As a UI/UX and technical writer, I excel in crafting user-centric interfaces and creating comprehensive technical documentation. Collaborating closely with my team, we successfully translated our ideas into a functional design, ensuring a seamless user experience. Witnessing the impact of our work on the digital landscape is truly fulfilling.</p><br><br>
                <p>My passion for this industry goes beyond my academic pursuits. I've always been fascinated by the power of technology and its ability to shape our world. In particular, I find myself constantly engrossed in reading news about the current trends in artificial intelligence. AI's advancements and potential applications never cease to amaze me, and staying updated with these developments will help me grow as a professional in the field.</p>">
                <img src="../Images/Cyril.jpg" alt="" />
                <div class="members-layer">
                    <h4>Cyril T. Torion</h4>
                    <a href="#"><i class='bx bx-link-external'></i></a>
                </div>
            </div>

            </div>
        </section>

        <!-- Popup Container for Member Info -->
        <div class="popup-container" id="popupContainer">
            <h2 class="popupTitle">MEMBER INFORMATION</h2>
            <img id="popupImage" src="" alt="" />
            <h4 id="popupTitle" class="popupTitle"></h4>
            <p id="popupDescription" class="popupDescription"></p>
            <button onclick="closePopup()">Close</button>
        </div>

        <!-- Separator -->
        <hr class="section-separator" />

        <!-- Connect with Us Section -->
        <section class="connect-with-us">
            <h1 class="heading">
                Connect <span class="heading1">With <span class="heading2">Us</span></span>
            </h1>
            <div class="connect-container">
                <!-- Facebook -->
                <div class="connect-box">
                    <div class="connect-icon">
                        <span class="lab la-facebook"></span>
                    </div>
                    <div class="connect-text">
                        <a href="#" target="_blank">Facebook</a>
                    </div>
                </div>
                <!-- Twitter -->
                <div class="connect-box">
                    <div class="connect-icon">
                        <span class="lab la-twitter"></span>
                    </div>
                    <div class="connect-text">
                        <a href="#" target="_blank">Twitter</a>
                    </div>
                </div>
                <!-- Gmail -->
                <div class="connect-box">
                    <div class="connect-icon">
                        <span class="las la-envelope"></span>
                    </div>
                    <div class="connect-text">
                        <a href="mailto:">Gmail</a>
                    </div>
                </div>
                <!-- Phone -->
                <div class="connect-box">
                    <div class="connect-icon">
                        <span class="las la-phone"></span>
                    </div>
                    <div class="connect-text">
                        <span>Telephone Number</span>
                        <p>+123-456-7890</p>
                    </div>
                </div>
            </div>
            <a href="about.php" class="read-more">Go Back?</a>
        </section>
    </div>

    <!-- Label for closing mobile menu -->
    <label class="close-mobile-menu" for="menu-toggle"></label>

    <!-- Logout Popup -->
    <div class="logout-popup-container" id="logoutPopup">
        <div class="popup-content">
            <img src="../Images/lock.png" alt="Logo" class="logo-image" />
            <h2>Logout Confirmation</h2>
            <p>Are you sure you want to logout?</p>
            <div class="button-container">
                <button class="btn" onclick="confirmLogout()">YES</button>
                <button class="btn closeBtn" onclick="closeLogoutPopup()">NO</button>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <script src="../JS/members.js"></script>
</body>
</html>